style_empty <- function(n) {
  ""
}

new_empty_shaft <- function(height = 1) {
  new_pillar_shaft_simple(rep("", height), width = 0)
}
