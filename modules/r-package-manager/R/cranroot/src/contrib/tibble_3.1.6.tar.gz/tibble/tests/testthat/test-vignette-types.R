test_that("types vignette", {
  test_galley("types")
})
