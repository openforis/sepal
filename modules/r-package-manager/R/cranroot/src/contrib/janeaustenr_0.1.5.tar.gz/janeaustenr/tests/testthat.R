library(testthat)
library(janeaustenr)

test_check("janeaustenr")
