globalVariables(c("sensesensibility", "prideprejudice", "mansfieldpark", 
                  "emma", "northangerabbey", "persuasion", "book"))
