---
title: "Extending tibble"
author: "Kirill Müller, Hadley Wickham"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{Extending tibble}
  %\VignetteEngine{knitr::rmarkdown}
  %\VignetteEncoding{UTF-8}
---

This material has moved to <https://vctrs.r-lib.org/articles/pillar.html>.
