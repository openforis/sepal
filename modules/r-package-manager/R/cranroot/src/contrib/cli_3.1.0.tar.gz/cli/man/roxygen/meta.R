list(
  markdown = TRUE,
  knitr_chunk_options = list(
    cache = TRUE,
    error = TRUE,
    cache.path = "man/_cache/"
  )
)
