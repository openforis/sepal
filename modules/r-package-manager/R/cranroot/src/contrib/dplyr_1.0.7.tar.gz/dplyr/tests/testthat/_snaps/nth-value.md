# nth() gives meaningful error message (#5466)

    Code
      nth(1:10, "x")
    Error <rlang_error>
      `n` must be a single integer.

