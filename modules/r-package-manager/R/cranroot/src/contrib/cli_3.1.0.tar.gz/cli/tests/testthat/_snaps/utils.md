# ruler

    Code
      ruler(20)
    Output
      ----+----1----+----2
      12345678901234567890

