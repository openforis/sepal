# all_exprs() gives meaningful error messages

    Code
      all_exprs()
    Error <rlang_error>
      At least one expression must be given.

---

    Code
      any_exprs()
    Error <rlang_error>
      At least one expression must be given.

